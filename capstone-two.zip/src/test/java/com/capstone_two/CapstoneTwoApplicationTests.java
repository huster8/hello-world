package com.capstone_two;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstoneTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
